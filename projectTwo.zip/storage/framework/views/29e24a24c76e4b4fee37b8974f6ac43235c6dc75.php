<?php echo e($slot); ?>

<?php /**PATH C:\newlARAVEL\test\laravel8\projectTwo\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>